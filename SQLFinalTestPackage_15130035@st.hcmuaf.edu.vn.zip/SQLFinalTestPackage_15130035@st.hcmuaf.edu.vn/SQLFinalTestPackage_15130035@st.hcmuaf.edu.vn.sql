DROP TABLE Employee
DROP TABLE Projects
DROP TABLE Project_Modules
DROP TABLE Work_Done
--Q1
CREATE TABLE Employee(
	EmployeeID varchar(6) not null primary key,
	EmployeeLastName varchar(20) not null,
	EmployeeFirstName varchar(20) not null,
	EmployeeHireDate date not null,
	EmployeeStatus varchar(100) not null,
	SupervisorID varchar(6) not null,
	SocialSecurityNumber varchar(15) not null
)
go
CREATE TABLE Projects(
	ProjectID varchar(6) not null primary key,
	ProjectName varchar(100) not null,
	ProjectStartDate date not null,
	ProjectDescription varchar(100) not null,
	ProjectDetail varchar(100) not null,
	ProjectCompletedOn date not null
)
go
CREATE TABLE Project_Modules(
	ModuleID varchar(6) not null primary key, 
	ProjectID varchar(6) not null,
	EmployeeID varchar(6) not null,
	projectModuleDate date not null,
	ProjectModuleCompledOn date not null,
	ProjectModuleDescription varchar(100) not null,
	FOREIGN KEY (EmployeeID) REFERENCES Employee (EmployeeID),
	FOREIGN KEY (ProjectID) REFERENCES Projects (ProjectID)
)
go
CREATE TABLE Work_Done(
	WorkDoneID varchar(6) primary key,
	ModuleID varchar(6) not null,
	WorkDoneDate date ,
	WorkDoneDescription varchar(100) not null,
	WorkDoneStatus varchar(100) not null,
	FOREIGN KEY (ModuleID) REFERENCES Project_Modules (ModuleID)
)
go
--Q2a

INSERT INTO Employee(EmployeeID, EmployeeLastName, EmployeeFirstName, EmployeeHireDate,	EmployeeStatus,	SupervisorID, SocialSecurityNumber)
VALUES ('EML101', 'Duc', 'Le', '2015-7-5', 'ready', 'SPV101', '325645824'),
	   ('EML102', 'Kien', 'Nguyen', '2015-2-5', 'ready', 'SPV102', '986545866'),
	   ('EML103', 'Hang', 'Le', '2015-2-5', 'ready', 'SPV103', '758458664')
go
INSERT INTO Projects(ProjectID, ProjectName, ProjectStartDate, ProjectDescription, ProjectDetail, ProjectCompletedOn)
VALUES ('PRO101', 'App', '2018-5-8', 'App mobile', 'game android', '2018-7-9'),
       ('PRO102', 'WebApp', '2018-4-6', 'Web App', 'Web App', '2018-7-9'),
       ('PRO103', 'WebService', '2018-2-7', 'Web Service', 'Web Service', '2018-7-5')
go
INSERT INTO Project_Modules(ModuleID, ProjectID, EmployeeID, ProjectModuleDate, ProjectModuleCompledOn, ProjectModuleDescription)
VALUES ('MD101','PRO101','EML101','2018-5-30','2018-6-6','game android'),
	   ('MD102','PRO102','EML102','2018-4-28','2018-4-5','Web App'),
	   ('MD103','PRO103','EML103','2108-2-20','2017-5-3','Web Service')
go
INSERT INTO Work_Done(WorkDoneID, ModuleID, WorkDoneDate, WorkDoneDescription, WorkDoneStatus)
VALUES ('WD101','MD101','2018-8-8','game android','final'),
	   ('WD102','MD102','2018-6-6','Web App','not final'),
	   ('WD103','MD103','2018-9-10','Web Service','final')
go
--Q2b
SELECT *
FROM Projects
WHERE DATEPART(MONTH, GETDATE()) - DATEPART(MONTH, Projects.ProjectCompletedOn) >= 3
AND DATEPART(DAY, GETDATE()) - DATEPART(DAY, Projects.ProjectCompletedOn) >= 0
GO
--Q2c
SELECT p.*
FROM Employee e INNER JOIN Project_Modules p ON e.EmployeeID = p.EmployeeID
WHERE e.EmployeeFirstName = 'Nguyen' AND e.EmployeeLastName = 'Kien'
GO
--Q2d
SELECT w.*
FROM Employee e INNER JOIN Project_Modules p ON e.EmployeeID = p.EmployeeID INNER JOIN Work_Done w ON w.ModuleID = p.ModuleID
WHERE e.EmployeeFirstName = 'Nguyen' AND e.EmployeeLastName = 'Kien' AND w.WorkDoneStatus = 'not final'